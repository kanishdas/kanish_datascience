import React, { useState, useEffect } from 'react';
import { ChefHat, Users, Eye, LogIn, Menu, X, ArrowLeft, ArrowRight, Leaf, Heart, Globe, Palette } from 'lucide-react';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  const carouselData = [
    {
      image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1200',
      tagline: 'Transform Yesterday\'s Leftovers Into Today\'s Masterpiece',
      subtitle: 'Every ingredient deserves a second chance'
    },
    {
      image: 'https://images.pexels.com/photos/1109197/pexels-photo-1109197.jpeg?auto=compress&cs=tinysrgb&w=1200',
      tagline: 'One Recipe at a Time, We\'re Saving the Planet',
      subtitle: 'Join thousands reducing food waste daily'
    },
    {
      image: 'https://images.pexels.com/photos/1633578/pexels-photo-1633578.jpeg?auto=compress&cs=tinysrgb&w=1200',
      tagline: 'Creativity Meets Sustainability in Your Kitchen',
      subtitle: 'Turn scraps into spectacular dishes'
    },
    {
      image: 'https://images.pexels.com/photos/769289/pexels-photo-769289.jpeg?auto=compress&cs=tinysrgb&w=1200',
      tagline: 'From Waste to Taste - The Savr Way',
      subtitle: 'Discover the art of leftover cuisine'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % carouselData.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % carouselData.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + carouselData.length) % carouselData.length);
  };

  const NavBar = () => (
    <nav className="bg-yellow-400 shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <ChefHat className="h-8 w-8 text-white" />
            <span className="text-2xl font-bold text-white">Savr</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <div className="relative group">
              <button className="flex items-center space-x-1 text-white hover:text-yellow-100 transition-colors">
                <span>Recipes</span>
                <ChefHat className="h-4 w-4" />
              </button>
              <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <button 
                  onClick={() => setCurrentPage('share-recipe')}
                  className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-yellow-50 hover:text-yellow-600 transition-colors"
                >
                  Share Recipe
                </button>
                <button 
                  onClick={() => setCurrentPage('browse-recipes')}
                  className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-yellow-50 hover:text-yellow-600 transition-colors"
                >
                  Browse Recipes
                </button>
              </div>
            </div>
            
            <button 
              onClick={() => setCurrentPage('about')}
              className="text-white hover:text-yellow-100 transition-colors"
            >
              About Us
            </button>
            
            <button 
              onClick={() => setCurrentPage('vision')}
              className="text-white hover:text-yellow-100 transition-colors"
            >
              Our Vision
            </button>
            
            <button 
              onClick={() => setCurrentPage('login')}
              className="bg-white text-yellow-600 px-4 py-2 rounded-lg hover:bg-yellow-50 transition-colors flex items-center space-x-1"
            >
              <LogIn className="h-4 w-4" />
              <span>Login</span>
            </button>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button 
                onClick={() => {setCurrentPage('share-recipe'); setIsMenuOpen(false);}}
                className="block w-full text-left px-3 py-2 text-gray-700 hover:bg-yellow-50"
              >
                Share Recipe
              </button>
              <button 
                onClick={() => {setCurrentPage('browse-recipes'); setIsMenuOpen(false);}}
                className="block w-full text-left px-3 py-2 text-gray-700 hover:bg-yellow-50"
              >
                Browse Recipes
              </button>
              <button 
                onClick={() => {setCurrentPage('about'); setIsMenuOpen(false);}}
                className="block w-full text-left px-3 py-2 text-gray-700 hover:bg-yellow-50"
              >
                About Us
              </button>
              <button 
                onClick={() => {setCurrentPage('vision'); setIsMenuOpen(false);}}
                className="block w-full text-left px-3 py-2 text-gray-700 hover:bg-yellow-50"
              >
                Our Vision
              </button>
              <button 
                onClick={() => {setCurrentPage('login'); setIsMenuOpen(false);}}
                className="block w-full text-left px-3 py-2 text-yellow-600 font-medium"
              >
                Login / Sign Up
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );

  const HomePage = () => (
    <div className="min-h-screen bg-white">
      {/* Hero Carousel */}
      <div className="relative h-96 md:h-[500px] overflow-hidden">
        {carouselData.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div 
              className="w-full h-full bg-cover bg-center"
              style={{
                backgroundImage: `url(${slide.image})`,
                filter: 'saturate(0.7) brightness(0.8)'
              }}
            >
              <div className="absolute inset-0 bg-black bg-opacity-40" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white px-4 max-w-4xl">
                  <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
                    {slide.tagline}
                  </h1>
                  <p className="text-lg md:text-xl opacity-90">
                    {slide.subtitle}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-full transition-all"
        >
          <ArrowLeft className="h-6 w-6" />
        </button>
        
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-full transition-all"
        >
          <ArrowRight className="h-6 w-6" />
        </button>

        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {carouselData.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white' : 'bg-white bg-opacity-50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* How We Work Section */}
      <div className="py-16 px-4 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            How We Work
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Savr empowers you to transform leftover ingredients into delicious meals, 
            creating a sustainable community that fights food waste one recipe at a time.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
            <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <ChefHat className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Share Your Creativity</h3>
            <p className="text-gray-600">
              Post recipes using leftover ingredients from your kitchen. Turn what others might waste into culinary masterpieces that inspire the community.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
            <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Build Community</h3>
            <p className="text-gray-600">
              Connect with like-minded individuals who share your passion for sustainability. Browse, rate, and get inspired by creative leftover recipes.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
            <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Leaf className="h-8 w-8 text-yellow-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Make Impact</h3>
            <p className="text-gray-600">
              Every recipe shared prevents food waste, reduces environmental impact, and creates a more sustainable future for generations to come.
            </p>
          </div>
        </div>

        {/* Impact Statistics */}
        <div className="bg-yellow-400 rounded-2xl text-white p-8 md:p-12">
          <div className="text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">The Impact We Can Create Together</h3>
            <p className="text-yellow-100 text-lg">
              When we work together to reduce food waste, the positive impact multiplies exponentially
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-white bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8" />
              </div>
              <h4 className="text-xl font-semibold mb-2">Environmental Impact</h4>
              <p className="text-yellow-100">
                Reducing food waste by just 25% could feed 870 million hungry people worldwide and significantly reduce greenhouse gas emissions.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-white bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8" />
              </div>
              <h4 className="text-xl font-semibold mb-2">Community Building</h4>
              <p className="text-yellow-100">
                Every shared recipe creates ripple effects, inspiring families and communities to be more mindful about food consumption and creativity.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-white bg-opacity-20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="h-8 w-8" />
              </div>
              <h4 className="text-xl font-semibold mb-2">Future Generations</h4>
              <p className="text-yellow-100">
                Teaching sustainable cooking practices today ensures a healthier planet and more resource-conscious future generations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const AboutPage = () => (
    <div className="min-h-screen bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => setCurrentPage('home')}
          className="flex items-center space-x-2 text-yellow-600 hover:text-yellow-700 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 text-center">
            Meet Team Script Techies
          </h1>
          
          <p className="text-lg text-gray-600 text-center mb-12 max-w-3xl mx-auto">
            We are a passionate team of four developers united by our mission to combat food waste 
            through innovative technology and community building.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-yellow-50 rounded-xl p-6 text-center">
              <div className="bg-yellow-200 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-10 w-10 text-yellow-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Aditya Pranav</h3>
              <p className="text-yellow-600 font-medium mb-3">Team Lead, Full Stack Developer</p>
              <p className="text-gray-600">
                Visionary leader and full stack developer driving our mission to create sustainable solutions for food waste reduction through innovative technology.
              </p>
            </div>

            <div className="bg-yellow-50 rounded-xl p-6 text-center">
              <div className="bg-yellow-200 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <ChefHat className="h-10 w-10 text-yellow-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Sanjana</h3>
              <p className="text-yellow-600 font-medium mb-3">Creative Functionality Developer</p>
              <p className="text-gray-600">
                Creative functionality developer focused on innovative features and building engaging experiences that make sustainability accessible to everyone.
              </p>
            </div>

            <div className="bg-yellow-50 rounded-xl p-6 text-center">
              <div className="bg-yellow-200 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="h-10 w-10 text-yellow-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Nikitha</h3>
              <p className="text-yellow-600 font-medium mb-3">UI/UX Designer</p>
              <p className="text-gray-600">
                UI/UX designer crafting beautiful and intuitive interfaces that make sustainable cooking feel natural and enjoyable for everyone.
              </p>
            </div>

            <div className="bg-yellow-50 rounded-xl p-6 text-center">
              <div className="bg-yellow-200 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="h-10 w-10 text-yellow-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Kanish</h3>
              <p className="text-yellow-600 font-medium mb-3">UI/UX Designer</p>
              <p className="text-gray-600">
                UI/UX designer passionate about creating meaningful visual connections between technology and environmental sustainability through thoughtful design.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Our Story</h3>
            <p className="text-gray-600 leading-relaxed max-w-3xl mx-auto">
              Script Techies was born from our shared concern about the alarming rate of food waste in our communities. 
              As technology enthusiasts, we realized we could leverage our skills to create a platform that not only 
              addresses this critical issue but also builds a community of conscious individuals working towards a more 
              sustainable future. Every line of code we write is driven by our commitment to making a positive impact on the world.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const VisionPage = () => (
    <div className="min-h-screen bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => setCurrentPage('home')}
          className="flex items-center space-x-2 text-yellow-600 hover:text-yellow-700 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 text-center">
            Our Vision: A World Without Food Waste
          </h1>
          
          <div className="mb-12">
            <div className="bg-red-50 border-l-4 border-red-400 p-6 mb-8">
              <h3 className="text-xl font-semibold text-red-800 mb-3">The Crisis We Face</h3>
              <div className="text-red-700 space-y-2">
                <p>• <strong>1.3 billion tons</strong> of food is wasted globally every year</p>
                <p>• <strong>1 in 9 people</strong> worldwide suffer from hunger</p>
                <p>• Food waste contributes to <strong>8-10% of global greenhouse gas emissions</strong></p>
                <p>• <strong>$1 trillion</strong> worth of food is wasted annually</p>
              </div>
            </div>

            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6">
              <h3 className="text-xl font-semibold text-yellow-800 mb-3">Our Beautiful Solution</h3>
              <p className="text-yellow-700 leading-relaxed">
                At Savr, we believe that every leftover ingredient has the potential to become something beautiful and delicious. 
                Our platform transforms the way people think about food waste by making it creative, fun, and socially rewarding. 
                We're not just reducing waste – we're building a movement of conscious cooks who see opportunity where others see trash.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">How We're Making a Difference</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-yellow-100 p-2 rounded-full">
                    <ChefHat className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Recipe Innovation</h4>
                    <p className="text-gray-600">Transforming leftovers into gourmet experiences through community creativity.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-yellow-100 p-2 rounded-full">
                    <Users className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Community Building</h4>
                    <p className="text-gray-600">Creating a supportive network of environmentally conscious food enthusiasts.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-yellow-100 p-2 rounded-full">
                    <Leaf className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Environmental Impact</h4>
                    <p className="text-gray-600">Reducing carbon footprint one recipe at a time through conscious consumption.</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">Our Long-term Goals</h3>
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Global Community</h4>
                  <p className="text-gray-600">Build a worldwide network of million+ users sharing sustainable recipes.</p>
                </div>
                
                <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Educational Impact</h4>
                  <p className="text-gray-600">Partner with schools and organizations to teach sustainable cooking practices.</p>
                </div>
                
                <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Technology Innovation</h4>
                  <p className="text-gray-600">Develop AI-powered suggestions for leftover ingredient combinations.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white rounded-xl p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Join Our Mission</h3>
            <p className="text-lg opacity-90 mb-6">
              Together, we can create a world where every ingredient is valued, every meal is appreciated, 
              and every person contributes to a more sustainable future.
            </p>
            <button 
              onClick={() => setCurrentPage('home')}
              className="bg-white text-yellow-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Start Your Journey
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const LoginPage = () => (
    <div className="min-h-screen bg-white py-16 px-4">
      <div className="max-w-md mx-auto">
        <button
          onClick={() => setCurrentPage('home')}
          className="flex items-center space-x-2 text-yellow-600 hover:text-yellow-700 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="text-center mb-8">
            <ChefHat className="h-12 w-12 text-yellow-600 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900">Welcome to Savr</h1>
            <p className="text-gray-600">Join the fight against food waste</p>
          </div>

          <form className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input
                type="password"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                placeholder="Enter your password"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-yellow-400 text-white py-3 rounded-lg hover:bg-yellow-500 transition-colors font-medium"
            >
              Sign In
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Don't have an account?{' '}
              <button className="text-yellow-600 hover:text-yellow-700 font-medium">
                Sign up here
              </button>
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200 text-center">
            <p className="text-sm text-gray-500">
              By joining Savr, you're taking a step towards a more sustainable future
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const ShareRecipePage = () => (
    <div className="min-h-screen bg-white py-16 px-4">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => setCurrentPage('home')}
          className="flex items-center space-x-2 text-yellow-600 hover:text-yellow-700 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Share Your Recipe</h1>
          <p className="text-gray-600 mb-8">Help others transform their leftovers into delicious meals</p>

          <form className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Recipe Title</label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="e.g., Leftover Rice Fried Rice"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Leftover Ingredients Used</label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="e.g., Rice, vegetables, meat"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Instructions</label>
              <textarea
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="Share your step-by-step instructions..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Cooking Time</label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="e.g., 15 minutes"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-yellow-400 text-white py-3 rounded-lg hover:bg-yellow-500 transition-colors font-medium"
            >
              Share Recipe
            </button>
          </form>
        </div>
      </div>
    </div>
  );

  const BrowseRecipesPage = () => (
    <div className="min-h-screen bg-white py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={() => setCurrentPage('home')}
          className="flex items-center space-x-2 text-yellow-600 hover:text-yellow-700 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </button>

        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Browse Recipes</h1>
          <p className="text-lg text-gray-600">Discover creative ways to use your leftover ingredients</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3, 4, 5, 6].map((recipe) => (
            <div key={recipe} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-yellow-400 to-yellow-500"></div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Recipe Title {recipe}</h3>
                <p className="text-gray-600 mb-4">Transform your leftover ingredients into this amazing dish...</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">15 mins</span>
                  <button className="text-yellow-600 hover:text-yellow-700 font-medium">
                    View Recipe
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPage = () => {
    switch (currentPage) {
      case 'about':
        return <AboutPage />;
      case 'vision':
        return <VisionPage />;
      case 'login':
        return <LoginPage />;
      case 'share-recipe':
        return <ShareRecipePage />;
      case 'browse-recipes':
        return <BrowseRecipesPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <NavBar />
      {renderPage()}
    </div>
  );
}

export default App;